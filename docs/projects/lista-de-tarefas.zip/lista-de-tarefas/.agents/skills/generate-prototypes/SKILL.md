---
name: generate-prototypes
description: Generate an interactive, navigable prototype of a feature as standalone HTML files — `index.html`, plus one extra `.html` per additional page when the feature has more than one page — using React + Ant Design 5 + Babel Standalone loaded exclusively from public CDNs, with JSX, mock data, and interactions inline in each file, plus a `flow-map.md` recording pages, transitions, and the requirement's open questions. Input is a feature requirement file (`requirement-file`). The theme comes from the project's root `DESIGN.md` through Ant Design's ConfigProvider. Output goes to an optional folder (`output-folder`, defaults to `prototypes`). No npm, no package.json, no bundler, no build step — every page opens by double-clicking it. Use this when the user wants a clickable prototype of a requirement.
allowed-tools: Bash, Read, Write, Edit, Glob, Grep, AskUserQuestion
---

# generate-prototypes

Produces an interactive, navigable prototype built with **React + Ant Design 5**, where every
dependency is loaded from a **public CDN**. The output is:
- `index.html`, the entry page;
- one extra standalone `.html` file per additional page, if the feature or app has more than one page;
- a `flow-map.md` describing the pages, the transitions between them, and the requirement's open
  questions.

Every page opens directly in a modern browser: no installation, no build step, no dev server.

Ease of execution matters more than production-grade architecture.

Every path below to this skill's own `references/` and `assets/` is relative to this `SKILL.md`
file's location, so resolve them against wherever this skill folder actually sits. That rule doesn't
apply to `requirement-file` or `output-folder`, which come from the user and are used exactly as
given.

## Mandatory rules

**Read `references/prototype-rules.md` before generating anything.** It's the source of truth for the
prototype rules. If anything in this skill seems to conflict with it, `prototype-rules.md` wins. In
short:

- Every page is **one self-contained `.html` file**. A single-page feature is just `index.html`. A
  feature with several pages gets one `.html` per page, and `index.html` is the entry page.
- Don't create separate `.js` or `.css` files. Each page has its own `<style>` block and its own
  `<script type="text/babel">`. Anything the pages share (theme, layout, mock data) is duplicated in
  each file.
- Use **Ant Design 5.x** as the primary UI library, and always prefer an existing Ant Design component.
- Load every dependency from a **public CDN** with pinned versions (`references/cdn-dependencies.md`).
- No package manager, no `package.json`, no bundler or build step.
- The theme always comes from the project's `DESIGN.md`. If `DESIGN.md` doesn't decide something, ask
  the user.
- The result must be **interactive and navigable**, with in-memory mock data. Open questions go in
  `flow-map.md`.

## Inputs

| Parameter | Required? | Default | Description |
|---|---|---|---|
| `requirement-file` | **Required** | — | Path to the feature requirement document (user story, epic, feature requirement, or freeform doc). If it isn't provided, ask the user before doing anything else. Don't guess or search the repo for a likely candidate. |
| `output-folder` | Optional | `prototypes` | Base directory. This run writes to `{output-folder}/{feature-slug}/`. Create the folder if it doesn't exist. |

The theme source isn't a parameter. It's always the project's root `DESIGN.md` (see Phase 0).

## Phase 0: read DESIGN.md and build the theme

Locate the project's `DESIGN.md` at the project root, per `references/antd-theming.md`: first the
root of the app/project the requirement belongs to, then the repository root. If none exists, stop and
ask the user. Read it on every run, and build the `ConfigProvider` `theme` object only from what it
says. **Never hardcode theme values.** Don't reuse values from memory or from earlier prototypes.

If DESIGN.md doesn't settle a theme decision the prototype needs (a missing token, or an ambiguous
mapping), **offer options and ask the user**, all together in one batch, before continuing. Don't
guess. The full procedure is in `references/antd-theming.md`.

## Phase 1: read the requirement

Read `requirement-file`. Determine the scope: **one page** (possibly with several views or states), or
**several pages**. Then extract the concrete UI affordances, business rules, exclusions, and every
`[NEEDS CLARIFICATION]`/`[ASSUMPTION]`. Full guidance is in `references/requirement-mapping.md` and
`references/flow-navigation.md`.

Also determine the requirement's **content language** from its prose, not its section headings. Use it
for `<html lang>`, the Ant Design `ConfigProvider locale`, `dayjs.locale`, and every piece of UI copy
the requirement doesn't spell out verbatim. Never default to English just because this skill's docs are
in English.

## Phase 2: map affordances to Ant Design components

Map each affordance to an Ant Design 5 component (`references/requirement-mapping.md`). Only when no
Ant Design component fits, compose a custom one from Ant Design primitives and theme tokens, and note
it in `flow-map.md`.

## Phase 3: write the pages

Write `index.html` and every extra page from `assets/index.html.skeleton`. The skeleton follows the
structure required by `references/prototype-rules.md`:
- in `<head>`: React → ReactDOM → Ant Design 5 → Babel → extra styles;
- in `<body>`: `<div id="root">` and a single `<script type="text/babel">`.

Replace every `{{UPPER_SNAKE}}` placeholder. Note that `style={{ … }}` in JSX is ordinary JSX, not a
placeholder. Then, in every page:

- keep the CDN tags on public CDNs with pinned versions (`references/cdn-dependencies.md`);
- paste the same theme built from DESIGN.md in Phase 0 (`references/antd-theming.md`);
- write the mock data, views, and real interactions (`references/component-authoring.md`);
- wire navigation: real links between pages, and React state for views inside a page
  (`references/flow-navigation.md`).

## Phase 4: write `flow-map.md`

Always write `flow-map.md` next to the pages, per `references/flow-navigation.md`. It has three parts:
- the pages table;
- the transitions table (page navigation kept separate from same-page state);
- the **Gaps / open questions** section. Every `[NEEDS CLARIFICATION]`/`[ASSUMPTION]` from the
  requirement goes there, together with everything that had to be assumed, theme decisions the user
  made, and any custom component or extra library.

## Phase 5: verify

- Scan every `.html`: each external `src`/`href` must point to a public CDN (jsdelivr/unpkg/cdnjs or
  Google Fonts). There must be no local script/style references, and the output folder may contain only
  `.html` files and `flow-map.md`.
- Every link between pages must point to a file that exists in the folder.
- Every page must carry the same theme, and every theme value must trace back to DESIGN.md or to a
  choice the user made in Phase 0.
- Every page must open via `file://` (double-click). If a browser tool is available, open each one,
  click through every view and link, and check the console for errors. Otherwise, ask the user to do
  it.
- Walk the requirement's acceptance criteria one by one and confirm each interaction really works
  (modal opens and closes, invalid form is blocked, filter updates the list, create/edit/delete change
  the data).

## Phase 6: report

Tell the user:
- where the files were written, and that they open by double-clicking `index.html` (internet access is
  needed for the CDNs);
- the pages and the main interactions implemented;
- which DESIGN.md was used, and any theme decisions the user made because DESIGN.md didn't cover them;
- a summary of the gaps and open questions recorded in `flow-map.md`;
- any custom (non-Ant Design) component or extra CDN library used, and why.

## Output location

```
{output-folder}/                ← "prototypes" unless overridden
  {feature-slug}/               ← kebab-case from the requirement's feature name
    index.html                  ← entry page (the only page, for single-page features)
    {page-slug}.html            ← one per additional page, only if the feature has several pages
    flow-map.md                 ← pages, transitions, gaps / open questions
```

Derive `{feature-slug}` from the requirement's title or feature name, and name each `{page-slug}` in
kebab-case, in the requirement's language (e.g. `detalhes.html`). If a slug is ambiguous, ask the
user.

## Reference docs

- `references/prototype-rules.md`: the prototype rules, and the source of truth whenever something conflicts
- `references/cdn-dependencies.md`: allowed public CDNs, pinned URLs, load order, exposed globals
- `references/antd-theming.md`: how to locate the project's DESIGN.md and build the Ant Design
  `ConfigProvider` theme from it, and how to ask the user when DESIGN.md doesn't decide
- `references/requirement-mapping.md`: turning a requirement into pages, views, and Ant Design
  components
- `references/component-authoring.md`: per-page structure, Ant Design-first authoring, real
  interactivity with mock data
- `references/flow-navigation.md`: one page vs. several pages, navigation, and the `flow-map.md` format
