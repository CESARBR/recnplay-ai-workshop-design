# generate-prototypes

Generates an interactive, navigable prototype of a feature from a requirement document. The result is
**standalone HTML pages** that open directly in the browser, plus a `flow-map.md`.

## How it works, in short

1. **Stack**: React 18 + Ant Design 5 + Babel Standalone. Everything is loaded from **public CDNs**
   (jsDelivr / unpkg / cdnjs) with pinned versions. No npm, no `package.json`, no bundler, no
   build step.
2. **One file per page**: a single-page feature is just `index.html`. A feature with several pages
   gets one `.html` per page, and `index.html` is the entry page. Each file is self-contained: its HTML,
   extra CSS (`<style>`), and JSX (`<script type="text/babel">`) with mock data and interactions.
3. **Ant Design first**: buttons, forms, tables, modals, drawers, tabs, menus, and so on always use
   Ant Design components.
4. **Theme from DESIGN.md**: the theme is always generated from the `DESIGN.md` at the project root,
   through `ConfigProvider` and Ant Design tokens. No value is hardcoded. When DESIGN.md doesn't decide
   something, the skill offers options and asks the user.
5. **Real interactivity**: create, edit, and delete on in-memory data, validated forms, working
   filters, tabs, and menus. Pages are linked by real navigation.
6. **`flow-map.md`**: lists the pages and transitions, and records the requirement's open questions
   (`[NEEDS CLARIFICATION]` / `[ASSUMPTION]`) and everything that had to be assumed.

Output: `{output-folder}/{feature-slug}/` containing `index.html`, the extra pages (if any), and
`flow-map.md`. The default `output-folder` is `prototypes`.

The rules live in `references/prototype-rules.md`, the source of truth for the prototype rules. See
`SKILL.md` for the exact flow and `references/` for the details.
