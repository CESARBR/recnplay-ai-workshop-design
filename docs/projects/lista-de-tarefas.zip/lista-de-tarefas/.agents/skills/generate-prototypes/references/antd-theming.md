# Theming Ant Design from DESIGN.md

The prototype's theme **always** comes from the project's `DESIGN.md`. Read that file every time you
generate a prototype, and build the `ConfigProvider` `theme` object from what it says at that moment.
Never hardcode theme values: no hex codes, font names, radii, or sizes typed from memory or copied from
examples, and nothing reused from an earlier prototype. Every value in `theme` must trace back to an
entry in `DESIGN.md`.

Ant Design 5 components are still the visual foundation. `DESIGN.md` doesn't replace them. It
**themes** them through `ConfigProvider`'s global tokens and per-component tokens.

## Locating DESIGN.md

`DESIGN.md` lives at the **project root**. Look for it in this order:

1. the root of the project the requirement belongs to, i.e. the app folder that contains the
   requirement file (for example `apps/<app>/DESIGN.md`, next to that project's `AGENTS.md`);
2. the repository root (`DESIGN.md`).

Use the first one you find. If neither exists, **stop and ask the user** where the DESIGN.md is (or
suggest generating one with the `extract-design-md` skill). Don't fall back to a default or invented
theme.

## Expected shape

The file has YAML frontmatter with `name`, `colors`, `typography`, `rounded`, `spacing`, and
`components`, followed by markdown sections that describe intent and usage. Read **both** parts. The
YAML gives the values, and the prose explains when each one applies (which color is the primary action,
which surface is the page background, and so on). Parse whatever keys are actually present.

If the frontmatter doesn't have this shape, stop and tell the user. Don't improvise tokens from an
arbitrary file.

Resolve `{colors.x}` / `{rounded.x}` / `{spacing.x}` / `{typography.x.y}` references to the literal
values they point to before putting them into the theme object. The theme is plain JS, and there are no
CSS custom properties to point at.

## Global tokens (`theme.token`)

For each Ant Design seed/map token below, find the DESIGN.md entry that plays that role. Use the
DESIGN.md prose to decide the role, not just the key name:

| Role in DESIGN.md | Ant Design token |
|---|---|
| main brand / primary action color (e.g. whatever `button-primary`'s background resolves to) | `colorPrimary` |
| success / warning / error / info colors | `colorSuccess`, `colorWarning`, `colorError`, `colorInfo` |
| page background / container surface | `colorBgLayout` / `colorBgContainer` |
| main text color | `colorText` |
| border / outline color | `colorBorder` |
| body typography font family | `fontFamily` (add a generic fallback such as `sans-serif`) |
| body typography font size, in px | `fontSize` (a number) |
| default / medium radius | `borderRadius` (a number) |
| small / large radius | `borderRadiusSM` / `borderRadiusLG` |

Only set a token from a value DESIGN.md defines. If a role the prototype needs has no clear entry, or
DESIGN.md is ambiguous (two colors could be "primary", or the prose contradicts the YAML), follow
"When DESIGN.md doesn't decide" below. Never guess. Ant Design derives hover, active, and disabled
shades from the seeds, so don't compute them by hand.

## Component tokens (`theme.components`)

When a DESIGN.md `components` entry clearly corresponds to an Ant Design component (`button-primary`
→ `Button`, `card` → `Card`, `input` → `Input`, and so on), move its values into that component's
tokens:

```js
components: {
  Button: {
    borderRadius:  /* DESIGN.md components.button-primary.rounded, resolved */,
    paddingInline: /* DESIGN.md components.button-primary.padding, horizontal part */,
  },
}
```

Use only token names that exist for that component in Ant Design 5. If a DESIGN.md value has no
matching token, add a small scoped rule in the `<style>` block of each page, with a comment naming
the DESIGN.md entry it comes from.

## When DESIGN.md doesn't decide

Sometimes the prototype needs a theme decision that DESIGN.md doesn't settle. Examples: no success or error
color, no radius for a component the screen uses, an entry that could map to more than one Ant Design
token, or a component with no DESIGN.md counterpart. In these cases **offer options and ask the user**
before writing the theme.

1. Collect every such decision while mapping DESIGN.md, and ask **once, as a batch**, not one at a time.
2. For each decision, offer 2–4 concrete options, each with a short rationale. Build the options from
   what DESIGN.md already has, for example:
   - reuse an existing DESIGN.md token that's close (name it: "use `colors.tertiary`");
   - derive it from an existing token (a lighter or darker variant of a DESIGN.md color);
   - keep Ant Design's default for that token;
   - the user supplies their own value.
   Put the option that's most consistent with DESIGN.md first and mark it as recommended.
3. Use `AskUserQuestion` when available (one question per decision, up to 4 per call). Otherwise use
   a numbered list in plain text, and wait for the answer.
4. Apply exactly what the user chose. In the theme object, mark those values with a comment such as
   `// not in DESIGN.md — chosen by user` so they can be told apart from DESIGN.md values.
5. List these decisions in the final report, so the user can add them to DESIGN.md later if they want.
   Don't edit DESIGN.md yourself.

## Fonts

If DESIGN.md names a font that's available on Google Fonts, load it with a
`<link href="https://fonts.googleapis.com/css2?family=...">` in `<head>`. That's a public CDN, so it's
allowed. Otherwise rely on the fallback stack.

## What not to do

- Don't hardcode any theme value. If it isn't in DESIGN.md, ask the user (see above). Don't guess.
- Don't rebuild Ant Design components in custom CSS to match DESIGN.md pixel for pixel. Tokens first,
  minimal CSS second.
- Don't write a separate `.css` file. Any extra CSS goes in the `<style>` block of each page.
- Don't let the theme differ between pages. Build it once and paste the same object into every `.html`.
- Don't edit `DESIGN.md`. This skill only reads it.
