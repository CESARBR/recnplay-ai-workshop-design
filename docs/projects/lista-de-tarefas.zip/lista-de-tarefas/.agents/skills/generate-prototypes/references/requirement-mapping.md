# Mapping a feature requirement to screens and Ant Design components

## Input shapes this skill reads

The requirement file can take a few common shapes. Adapt to whichever one you're given:

- **User story shape**: sections such as `Acceptance Criteria`, `Negative Scope`, `Dependencies`,
  `UI Specifications`, `Design References`, `Notes`. These may carry `[NEEDS CLARIFICATION]` or
  `[ASSUMPTION]` tags. Treat those as explicit gaps and never resolve them silently.
- **Epic shape**: adds `Key Capabilities` and a list of the user stories it spans.
- **Feature requirement doc** (for example, the output of `generate-requirement`): Functional Requirements,
  Business Rules, Non-Functional Requirements, Negative Scope, Gaps & Open Questions.
- **Freeform doc**: read for the same information (what the user does, what the system shows or
  validates, explicit exclusions), even if the headers differ.

## Determining scope

- One page, or a few visual states of one page → only `index.html`, with the states reachable inside
  it.
- Several distinct pages (separate destinations the user navigates to) → one standalone `.html` per
  page, with `index.html` as the entry page and real links between them (`flow-navigation.md`).

Match the number of pages to what the source doc implies. Don't split a single page into several
files, and don't squeeze genuinely separate pages into one file.

## Reading order

1. **Acceptance Criteria / Functional Requirements / UI Specifications**: the primary source. Each
   bullet is a candidate UI affordance (a control, a state change, a validation rule, displayed data).
2. **Business Rules**: they drive validation `rules`, default sort order, derived states (overdue, done),
   and the options available in selects.
3. **Negative Scope / Out of scope**: don't build UI for these, even if it would be nice to have.
4. **Dependencies**: prototype code can't reuse real app code. Represent the concept with the closest
   Ant Design component, backed by mock data.
5. **`[NEEDS CLARIFICATION]` / `[ASSUMPTION]` tags**: carry them verbatim into the Gaps / open
   questions section of `flow-map.md`.

## Affordance → Ant Design component

| UI concept in the requirement | Ant Design component(s) |
|---|---|
| primary / secondary call to action | `Button type="primary"` / `Button` |
| create / edit form | `Modal` or `Drawer` containing `Form` + `Form.Item rules` |
| delete / destructive action | `Button danger` inside a `Popconfirm` |
| list of records with columns | `Table` with `sorter` / `filters`, or `List` for a lighter layout |
| cards / dashboard metrics | `Card`, `Statistic`, `Progress` |
| status label (priority, category, overdue) | `Tag` / `Badge`, colored by status |
| mark done / toggle | `Checkbox` / `Switch` |
| search | `Input.Search` |
| filter bar | `Select`, `DatePicker.RangePicker`, `Segmented` inside a `Flex`/`Space` (or a `Card`) |
| period views (day / week / all) | `Segmented` or `Tabs` |
| page chrome / navigation | `Layout` + `Menu`, `Breadcrumb` |
| multi-step wizard | `Steps` + Next/Back state |
| timer / progress (for example meditation) | `Progress type="circle"` + `Button`s driving a real `setInterval` |
| calendar view | `Calendar` |
| empty state | `Empty` |
| success / error feedback | `message`, `notification`, `Alert`, `Result` |

Extend this table as new patterns come up. If no Ant Design component fits an affordance, compose a
custom one from Ant Design primitives and theme tokens (`component-authoring.md`), and mention it in
the report.

## What to do with genuine gaps

When something is ambiguous or tagged in the source doc:
- don't invent a resolution silently;
- build the UI that best represents the *intent*;
- record the gap in the Gaps / open questions section of `flow-map.md` (`flow-navigation.md`).
