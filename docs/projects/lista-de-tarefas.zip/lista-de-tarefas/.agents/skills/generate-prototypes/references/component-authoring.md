# Authoring the prototype pages

Each page is one standalone `.html` file, started from `assets/index.html.skeleton`. A single-page
feature has only `index.html`. A feature with several pages has one file per page, and `index.html`
is the entry page (see `flow-navigation.md`). Each file contains the CDN tags, one `<style>` block,
and one `<script type="text/babel">` with the React app, mock data, and interactions. There are no
other `.js`/`.css` files, no `package.json`, and no build step.

## Structure inside the script

Keep this order in every page, so each file reads top to bottom:

1. **Destructure globals**: `const { useState } = React; const { Button, Table, ... } = antd; const { PlusOutlined } = icons;`
2. **Theme**: the `theme` object built from the project's DESIGN.md (`antd-theming.md`). It's identical in
   every page.
3. **Pages list**: `PAGES` and `CURRENT_PAGE`, identical in every page apart from `CURRENT_PAGE`.
4. **Mock data**: plain arrays/objects with realistic content in the requirement's language, and
   dates created with `dayjs()`. Use the same records and ids across pages.
5. **Shared layout**: header with the navigation `Menu` between pages, identical in every page.
6. **Views of this page**: one function component per view, state, or overlay (`TaskListView`,
   `TaskFormModal`, and so on), holding this page's in-memory state.
7. **Root**: `ConfigProvider` (theme + locale) → `antd.App` → layout + page, rendered with
   `ReactDOM.createRoot`.

Wrap everything in `antd.App` and get `message` / `modal` / `notification` from
`AntApp.useApp()`, so they pick up the theme. Don't use the static `message.success(...)` calls.

## Always prefer Ant Design components

Before writing any custom element, check whether Ant Design 5 has a component for it:

| Need | Ant Design component |
|---|---|
| actions | `Button`, `Dropdown`, `Popconfirm` (confirm before destructive actions) |
| forms | `Form` + `Form.Item` (with `rules` for validation), `Input`, `Input.TextArea`, `InputNumber`, `Select`, `DatePicker`, `TimePicker`, `Checkbox`, `Radio`, `Switch`, `Slider` |
| lists / data | `Table` (with `sorter`, `filters`), `List`, `Card`, `Descriptions`, `Tag`, `Badge`, `Statistic`, `Progress`, `Empty` |
| overlays | `Modal`, `Drawer`, `Popover`, `Tooltip` |
| navigation | `Layout`, `Menu`, `Tabs`, `Segmented`, `Steps`, `Breadcrumb`, `Pagination` |
| feedback | `message`, `notification`, `Alert`, `Result`, `Spin`, `Skeleton` |
| layout | `Row` / `Col`, `Flex`, `Space`, `Divider`, `Typography` |

Build a custom element only when none of these fits. Even then, compose it from Ant Design primitives
(`Card`, `Flex`, `Typography`) and theme tokens (`theme.useToken()`) rather than raw HTML and new
CSS.

## Everything the brief implies must work

The prototype is interactive, not a mockup. For each interaction the requirement implies, implement
the smallest real version of it on top of in-memory React state:

- **Create / edit / delete**: a `Modal` or `Drawer` with a `Form`. On submit, update the state array.
  Delete goes through `Popconfirm`. Show feedback with `message.success`.
- **Form validation**: use `Form.Item rules` (`required`, `type: 'email'`, `min`, custom `validator`).
  Invalid submits must be blocked and show errors on the field.
- **Filters / search / sort**: keep the source array in state and derive the visible list with `useMemo`
  from the filter values. Use `Table` `sorter` / `filters` where they fit.
- **Tabs / segmented views / menus**: switch real content, not just the highlighted tab.
- **Selects**: always provide real `options` taken from the requirement or the mock data.
- **Visual states the brief describes** (overdue, done, empty, error): derive them from the data
  (for example `dayjs(item.due).isBefore(dayjs())` → red `Tag`), and include mock data that triggers each
  one.
- **Async/loading states**: only if the requirement describes them. Then simulate them with a short
  `setTimeout` and a comment saying it's simulated.

No backend, database, or real API. Data lives in memory and resets on reload unless the requirement
explicitly needs persistence. In that case, use `localStorage` and say so in the report.

## Language

All UI copy (labels, placeholders, confirmations, empty states, toasts) is written in the
requirement's content language. Set `<html lang>`, `ConfigProvider locale` (`antd.locales.pt_BR`,
`antd.locales.en_US`, …), and `dayjs.locale(...)` to match. The English words in this skill's docs are
only examples.

## Extra CSS

Only for layout details that Ant Design props and theme tokens can't express. Put it in the single
`<style>` block with short, scoped class names. Never restyle Ant Design components wholesale.

## Checklist

- Every page opens by double-clicking its `.html` file and renders with no console errors.
- All dependencies load from public CDNs with pinned versions (`cdn-dependencies.md`).
- Every interaction in the requirement does something real.
- Every screen or state from the requirement can be reached from the UI.
- Nothing listed in the requirement's negative scope was built.
