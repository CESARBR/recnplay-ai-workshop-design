# CDN dependencies

Every dependency is loaded from a **public CDN** through a plain `<script src>` / `<link href>` tag,
so every prototype page runs by opening its `.html` file directly in a browser — no install, no build, no local
server.

## Allowed CDNs

Use only public, anonymous, no-auth CDNs:

- `https://cdn.jsdelivr.net/npm/...` (default — use this unless a package isn't available there)
- `https://unpkg.com/...`
- `https://cdnjs.cloudflare.com/ajax/libs/...`

Never use:

- internal/corporate registries, artifact mirrors, or intranet hosts;
- URLs that need a login, token, API key, or VPN;
- local copies of libraries (`./vendor/react.js`, `node_modules/...`);
- ESM-only "build on the fly" services that need an import map or bundler (`esm.sh`, `skypack`, `jspm`). The
  standard setup below uses UMD globals, which work with plain `<script>` tags.

## Pinned versions and load order

Pin exact versions so the prototype always renders the same way. Load them in this order, since each
UMD bundle depends on the globals set by the ones before it:

```html
<!-- React 18 (React 19 no longer ships UMD builds — stay on 18.x) -->
<script crossorigin src="https://cdn.jsdelivr.net/npm/react@18.3.1/umd/react.production.min.js"></script>
<script crossorigin src="https://cdn.jsdelivr.net/npm/react-dom@18.3.1/umd/react-dom.production.min.js"></script>

<!-- dayjs — required by Ant Design 5 (DatePicker, TimePicker, Calendar) -->
<script src="https://cdn.jsdelivr.net/npm/dayjs@1.11.13/dayjs.min.js"></script>
<!-- only if the UI language isn't English, e.g. pt-br -->
<script src="https://cdn.jsdelivr.net/npm/dayjs@1.11.13/locale/pt-br.js"></script>

<!-- Ant Design 5 (the "with-locales" build exposes antd.locales.pt_BR etc.) -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/antd@5.24.9/dist/reset.css" />
<script src="https://cdn.jsdelivr.net/npm/antd@5.24.9/dist/antd-with-locales.min.js"></script>

<!-- Ant Design icons (optional, only if icons are used) -->
<script src="https://cdn.jsdelivr.net/npm/@ant-design/icons@5.6.1/dist/index.umd.min.js"></script>

<!-- Babel Standalone — compiles <script type="text/babel"> JSX in the browser -->
<script src="https://cdn.jsdelivr.net/npm/@babel/standalone@7.26.10/babel.min.js"></script>
```

If a newer patch release is known to exist, you may bump the version. Keep the **major** versions
the same: React 18, Ant Design 5, `@ant-design/icons` 5, dayjs 1, and Babel 7.

Ant Design 5 uses CSS-in-JS, so the only stylesheet it needs is `reset.css`. Don't add
`antd.min.css`, because it doesn't exist in v5.

## Globals exposed

| Global | From | Typical use |
|---|---|---|
| `React` | react | `const { useState, useMemo } = React;` |
| `ReactDOM` | react-dom | `ReactDOM.createRoot(document.getElementById('root')).render(<App />)` |
| `dayjs` | dayjs | dates in mock data, DatePicker values |
| `antd` | antd | `const { Button, Table, ConfigProvider, App: AntApp } = antd;` |
| `antd.locales` | antd-with-locales | `antd.locales.pt_BR` for `ConfigProvider locale` |
| `icons` | @ant-design/icons | `const { PlusOutlined, DeleteOutlined } = icons;` |
| `Babel` | @babel/standalone | picks up `<script type="text/babel">` automatically |

## Extra libraries

Only add another library if the requirement actually needs something that neither Ant Design nor a
few lines of JS can provide (for example, a real chart). When you do:

- it must come from one of the allowed CDNs above, with a pinned version;
- it must expose a UMD/global build that works from a plain `<script src>`;
- mention it in the Phase 5 report.

For charts, prefer `@ant-design/plots` (Ant Design's own charting library) loaded from jsDelivr as a
UMD bundle, before reaching for anything else.
