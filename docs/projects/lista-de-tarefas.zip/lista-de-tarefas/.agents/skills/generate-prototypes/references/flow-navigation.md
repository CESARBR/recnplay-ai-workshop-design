# Pages, navigation, and the flow map

## One page or several

- **One page**: the feature is a single page, or a few states/views of the same page (tabs, a filter
  bar, a modal-based create/edit, and so on). Generate only `index.html`, and switch views inside it
  with React state.
- **Several pages**: the feature or app has distinct pages, meaning separate destinations a user
  navigates to (for example "list", "details", "settings", or the steps of an onboarding that live on
  separate pages). Generate **one HTML file per page**, and make `index.html` the entry page.

Match the number of pages to what the requirement describes. Don't split a single page into several
files, and don't squeeze genuinely separate pages into one file.

## Every page is standalone

Each `.html` file follows every rule in `SKILL.md` on its own:
- it has its own CDN tags (`cdn-dependencies.md`);
- it has its own `<style>` block and its own `<script type="text/babel">`;
- it opens directly by double-clicking it.

No shared `.js`/`.css` files are allowed, so anything the pages have in common is **duplicated
identically** in each file:
- the `theme` object (built once from DESIGN.md in Phase 0, then pasted unchanged into every page);
- the shared layout/header component, with its navigation `Menu`;
- the mock data each page needs, using the same records and the same ids, so the pages stay coherent.

## Navigation

- **Between pages**: use real browser navigation to the sibling file, for example a `Menu` item whose
  `onClick` sets `window.location.href = 'detalhes.html'`, or `<a href="detalhes.html">`. To open a
  specific record, pass it in the query string (`detalhes.html?id=3`) and read it with
  `new URLSearchParams(location.search)`.
- **Inside a page**: use React state (`Tabs`, `Segmented`, `Steps`, `Modal`, `Drawer`) for views and
  states of that same page.

Each page load starts from its mock data. Changes made on one page (for example a created item) are
**not** carried to the next page by default. If the requirement genuinely needs that to make sense,
persist the data in `localStorage` (and seed it from the mock data when it's empty). Record that
choice in `flow-map.md`.

## Reaching every state

Every page and every visual state named in the requirement (empty list, error, success, and so on)
must be reachable by clicking through the UI. If a state can't arise naturally from the mock data
(for example an empty state when mock data exists), add a small, clearly labelled way to reach it,
such as a "Limpar dados" button or a `Segmented` "demo state" switcher in the header.

## `flow-map.md`

Always write a `flow-map.md` next to the HTML files. It documents the pages and transitions, and it's
where the requirement's doubts and gaps are recorded:

```markdown
# {Feature Name} — flow map

Source: `{path to the requirement file}`
Theme: `{path to the DESIGN.md used}`

## Pages

| page | file | represents |
|---|---|---|
| 1 | index.html | Task list with filters |
| 2 | detalhes.html | Details of one task |

## Transitions

| from | trigger | to | type |
|---|---|---|---|
| index.html | click a task | detalhes.html?id={id} | page navigation |
| index.html | click "Nova tarefa" | create modal | same-page state |

## Gaps / open questions

- [NEEDS CLARIFICATION]: … (carried verbatim from the requirement)
- [ASSUMPTION]: … (carried verbatim from the requirement)
- Anything that had to be guessed, and why
- Theme decisions not covered by DESIGN.md, and what the user chose
- Custom (non-Ant Design) components or extra CDN libraries used
- Data persistence across pages (`localStorage`), if used
```

For a single-page prototype, keep only the one row in the Pages table, and list only same-page
transitions. The Gaps section stays.

In the Transitions table, keep **page navigation** (a different `.html` file) clearly separate from
**same-page state** changes (tabs, modals, drawers). Don't mix the two up.
