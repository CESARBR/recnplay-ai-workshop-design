## Prototype Generation Rules

The prototype must be created as **standalone HTML files** that run directly in a web browser, with no
installation, build step, or development server.

### Mandatory Requirements

- Each page of the prototype must be contained in a single, self-contained `.html` file.
  - If the feature or app has only one page, the prototype is just `index.html`.
  - If it has more than one page, create one `.html` file per page, and use `index.html` as the entry page.
- Use **Ant Design 5** as the primary UI component library.
- Use Ant Design components whenever an appropriate component exists, instead of recreating elements such
  as buttons, inputs, selects, tables, modals, drawers, tabs, cards, menus, and forms manually.
- Load React, ReactDOM, Ant Design, and any other required dependency through a **public CDN**
  (jsDelivr, unpkg, or cdnjs), with pinned versions. Never use internal or private registries, URLs that
  require authentication, or local copies of libraries.
- Every page must work by simply opening its `.html` file in a modern web browser.
- Do not use `npm`, `yarn`, `pnpm`, or any other package manager.
- Do not create a `package.json`.
- Do not use Vite, Next.js, Webpack, or any other bundler or framework that requires a build step.
- Do not create separate JavaScript or CSS files.
- Any additional CSS must be included directly inside each `.html` file.
- JavaScript and JSX must remain inside each `.html` file.
- Anything shared between pages (theme, layout, mock data) is duplicated in each file.
- Babel Standalone may be loaded through a public CDN to enable JSX directly in the browser.
- The final result must be an **interactive and navigable prototype**, not just a static visual mockup.

### Ant Design

Use **Ant Design version 5.x**.

When necessary, load the following dependencies through a public CDN:

- React
- ReactDOM
- Ant Design 5
- Babel Standalone

Ant Design components should form the visual foundation of the prototype.

Always prefer existing Ant Design components and patterns before creating custom UI components.

### Theme

- The theme must always be generated from the project's `DESIGN.md`, located at the project root.
- Apply the theme through `ConfigProvider` and Ant Design design tokens, using additional CSS only when
  tokens can't express something.
- Do not hardcode theme values. Every value must come from `DESIGN.md`.
- If `DESIGN.md` doesn't settle a decision, present options and ask the user.
- Every page must use the same theme.

### Expected Structure

Each page should follow approximately this structure:

```html
<!DOCTYPE html>
<html>
<head>
  <!-- React -->
  <!-- ReactDOM -->
  <!-- Ant Design 5 -->
  <!-- Babel -->
  <!-- Additional styles -->
</head>

<body>
  <div id="root"></div>

  <script type="text/babel">
    // React application
    // Ant Design components
    // Mock data
    // Prototype interactions
  </script>
</body>
</html>
```

The output folder looks like this:

```
{feature-slug}/
  index.html          ← entry page (the only page, for single-page features)
  {page-slug}.html    ← one per additional page, only if there are several pages
  flow-map.md         ← pages, transitions, and open questions
```

### Prototype Behavior

Whenever the product brief implies an interaction, implement it in the prototype.

For example:

- Buttons should perform actions.
- Modals should open and close.
- Tabs should switch content.
- Forms should allow user input.
- Select components should contain usable options.
- Menus should support navigation.
- Filters should update the displayed data when relevant.
- Create, edit, and delete actions may operate on mock data stored in memory.
- Different states of the same page may be simulated within the same HTML file.
- Different pages navigate to each other through real links between the HTML files.

A backend, database, or real APIs are not required.

Use mock data whenever necessary.

### Flow Map and Open Questions

Always create a `flow-map.md` next to the HTML files. It lists:

- the pages and what each one represents;
- the transitions between pages and between states of the same page;
- the requirement's open questions (`[NEEDS CLARIFICATION]` / `[ASSUMPTION]`), everything that had to be
  assumed, and theme decisions made by the user.

### Goal

The goal is to maximize prototyping speed and allow anyone to run and evaluate the result without
configuring a development environment.

Therefore, **ease of execution is more important than production-grade architecture**.

The final deliverable is a set of self-contained `.html` files, one per page with `index.html` as the
entry point, plus a `flow-map.md`. Each file is ready to open directly in a browser.
