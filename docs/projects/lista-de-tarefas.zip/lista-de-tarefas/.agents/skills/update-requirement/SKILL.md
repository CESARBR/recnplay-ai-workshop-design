---
name: update-requirement
description: >-
  Apply new inputs — meeting notes, an email, a PDF, a screenshot, a URL, updated code — as an incremental update to an existing requirement document, and propagate the resulting delta into a given folder of related prototype files. Diffs new sources against what the requirement already says, edits only what changed (minimum diff, existing structure and conventions preserved), records a dated revision-history entry citing the new sources, and reports anything it could not confidently map into the prototypes as a gap rather than guessing. Self-contained: works on any existing requirement file and any prototype folder, in any project, with no dependency on how either was originally produced.
---

# update-requirement

Takes a requirement that already exists and a prototype (or set of prototype files) built from it, and brings both up to date with new information — a meeting's decisions, an email thread, a revised PDF spec, a corrected screenshot — without regenerating either from scratch.

This is an **update**, not a rewrite: everything in the requirement and the prototypes that the new sources don't touch stays exactly as it was.

## When to use

- "update this requirement with the notes from today's meeting"
- "apply this email to the requirement and its prototype"
- "the spec changed, update the requirement and the prototype folder to match"
- "/update-requirement <input-sources> --requirement <path> [--prototypes <folder>]"

Do NOT use for:

- **Creating a requirement that doesn't exist yet.** This skill only edits a file you already have; point it at that file, not at a blank page.
- **Regenerating a prototype from scratch.** This applies the delta to files that already exist in the given folder — it does not build new prototype files where none exist, and it does not touch files outside that folder.
- **Reconciling many unrelated requirements or prototypes against each other at once.** This is a one-requirement, one-prototype-folder pass per run.

## Inputs

- **input-sources** (required): one or more new inputs, comma-separated. Each may be:
  - a local text/markdown file (`.txt`, `.md`)
  - a local PDF (`.pdf`)
  - a local image (`.png`, `.jpg`, `.jpeg` — a screenshot, whiteboard photo, annotated mockup)
  - a URL (a live page, a shared doc link)
  - a path to a code repo or directory (read as supporting context, not transcribed)
  - literal pasted text (a meeting-notes dump, an email body) — if an entry isn't a resolvable file path or URL, treat it as inline text content, not an error
- **requirement-file** (required): path to the existing requirement document to update.
- **prototypes-folder** (optional): path to a folder containing the prototype file(s) built from that requirement. If given, its contents are updated to match the delta; if omitted, only the requirement file is updated. Point this at the specific folder for **this** feature's prototype — if prototypes for several features (or a shared vendor/asset bundle) live under one parent directory, pass the feature's own subfolder, not the shared parent, so Step 1 doesn't have to sort unrelated files out of the way.

## Steps

### 1. Read the existing artifacts first

Before touching any new source, read what already exists — you're diffing against it, not composing from nothing:

- Read **requirement-file** in full. Note its actual section headings and structure as you find them — don't assume it follows any particular template. Whatever headings, ordering, and conventions (bullet style, a "Source:" citation field, checkbox acceptance criteria, etc.) it already uses are the ones you edit within.
- If **prototypes-folder** was given, list and read its files. Note the stack/format actually in use (plain HTML/CSS/JS, a component framework, whatever it is) and its existing conventions (naming, structure, how copy and data currently appear) before planning any change — you're extending an existing pattern, not introducing a new one.

### 2. Read every new source, per its type

Read all sources in parallel where the tool allows it.

| Source type | How to read it |
|---|---|
| `.txt` / `.md` file | Read directly. |
| `.pdf` | Read directly (the Read tool extracts text/pages); for a large PDF, request specific page ranges rather than the whole thing blind. |
| Image | Read directly — transcribe visible text, UI structure, and any handwritten annotations. |
| URL | Fetch it. |
| Code repo / directory | Skim for the specific thing relevant to the update — don't transcribe the codebase. |
| Inline text | Use as given. |

Keep a short scratch note of what each source contributed — needed for citations in Step 4 and the Step 6 report.

### 3. Diff the new sources against the requirement

For each fact in the new sources, classify it against the existing requirement content:

| Classification | Meaning | Action |
|---|---|---|
| **New** | Not covered by the requirement at all | Add it to the section it fits best, following that section's existing style. Create the section only if the file's own conventions support it (e.g. it already has sibling sections at that level) and the content genuinely doesn't fit elsewhere. |
| **Changed** | Alters something the requirement already states | Edit that content in place. If the requirement marks the prior state as a firm decision (e.g. a `[RESOLVED]` tag or similar), don't silently overwrite it — edit it, and record the change explicitly in the revision history (Step 5) as a decision reversal, not a routine addition. |
| **Resolves an open question** | Answers something the requirement had flagged as unresolved (e.g. a `[NEEDS CLARIFICATION]` item) | Remove the tag and fold the answer into the relevant section — don't leave a resolved item still marked `[NEEDS CLARIFICATION]`. |
| **Contradicts another new source** | Two new sources disagree with each other | Do not silently pick one — surface the conflict in the report (Step 6) and, if the requirement has a place for open conflicts, log it there instead of guessing. |
| **Not mentioned** | The requirement already covers it and no source touches it | Leave untouched. |

Never invent a specific number, name, or detail that isn't in a source — the same discipline applies to updates as to first-draft extraction. If a source is ambiguous about whether it changes existing content or adds new content, prefer the reading that requires the smaller edit, and note the ambiguity in the report.

### 4. Edit the requirement file — minimum diff

Apply the classified changes with targeted edits, not a full rewrite:

- Touch only the lines that changed. A single reworded acceptance criterion should produce a single edited line, not a regenerated section.
- Preserve the file's existing heading text, ordering, list style, and any citation convention it already uses — match it for new content too.
- Cite the new source for anything added or changed, using whatever citation style the file already has (a `Source:` field, an inline reference, a footnote) — if it has none, add a short parenthetical citation rather than inventing a new convention wholesale.

### 5. Record the update

Add or append to a revision-history record in the requirement file — if the file already has one (however it's labeled: "Revision History", "Changelog", "Change Log"), append a new dated entry to it; if it has none, add one short section for this at the end of the file. Each entry: date, which sources drove the update, and a one-line summary of what changed. This is additive only — never edit or remove a prior entry.

### 6. Update the prototypes, if a folder was given

For each change from Step 3 that has a UI or user-facing-behavior impact:

1. Search the prototype folder's files for the location that implements the affected part of the requirement (matching copy text, labels, field names, structural markers, mock data values).
2. If found, apply the minimum edit needed to bring it in line with the change — using the file's own existing patterns, components, and tech stack. Don't introduce a new library, framework, or structural pattern to make a small change fit.
3. If a change requires something the prototype folder has no analogous pattern for (a wholly new interaction, a component type not otherwise used there), do not invent one from scratch, and do not add or edit any DESIGN.md-style design-system file yourself — that's a shared, cross-feature file and out of scope for this skill's minimum-diff edits. Instead record it as a **gap** in the report, with what precedent (if any) came closest, and flag it as a follow-up: re-run the `generate-prototypes` skill against the updated requirement to regenerate the prototype with the new interaction or component.
4. Never touch a file outside the given prototypes folder, and never modify a part of a prototype file that the diff in Step 3 didn't call for.

If a change from Step 3 has no UI or user-facing-behavior impact (a pure business-rule clarification with no visible effect, for instance), it's fine for nothing in the prototype folder to change — don't force an edit to "use" every change.

### 7. Report

- **Requirement file**: which sections were added to, which were edited, and which revision-history entry was written.
- **Prototype folder** (if given): which files were edited and what changed in each, in the same terms as the requirement delta that drove it.
- **Gaps**: any change that couldn't be confidently mapped into the prototype folder, and why. For any gap caused by a missing interaction or component, name the recommended follow-up explicitly: re-run `generate-prototypes` against the updated requirement to regenerate the prototype — don't leave the reader to infer that step.
- **Conflicts**: any disagreement between new sources, surfaced rather than silently resolved.
- **Citations**: which source drove which change, so a reviewer can verify without re-reading everything.

## Scope

This skill touches exactly three things: the given **requirement-file**, the given **prototypes-folder** (if provided), and nothing else. It does not create either from nothing, does not reconcile them against any other requirement or prototype, and does not rewrite content the new sources didn't touch.
