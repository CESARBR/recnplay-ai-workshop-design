---
name: generate-requirement
description: >-
  Build a single feature-level requirements document from a set of source files — text notes, PDFs, screenshots/images, a URL, or a code repo/directory — following a standard requirements-document template (Overview, Functional Requirements, Business Rules, Non-Functional Requirements, Dependencies, Assumptions, Negative Scope, Gaps & Open Questions, etc.). Reads every source, extracts only what's explicitly documented, cites sources per requirement, and omits any section the sources don't support rather than inventing content or leaving placeholder text. Self-contained: works in any project, with no other skill or prior requirement catalog required.
---

# generate-requirement

Turns a handful of raw materials — meeting notes, a spec doc, screenshots of a whiteboard, a PDF, a URL, a code repo — into one requirement document in a consistent shape, so every generated requirement reads the same way regardless of what it was built from.

Depends on `requirement-template.md`, which lives in this skill's own directory — the same folder as this `SKILL.md` file, wherever that folder is. Every generated requirement is that template, filled in — never restructured, renamed, or reordered per run. If the template changes, every future run picks up the change automatically; this skill does not hardcode the section list.

## When to use

- "turn these notes into a requirement"
- "generate a requirement from this PDF / screenshot / repo"
- "/generate-requirement <input-sources>"
- "write up a requirement from this Slack thread export + these mockups"

Do NOT use for:

- **Rewriting or reconciling an existing catalog of many requirements against each other** (renumbering, cross-story dependency graphs). That's a bigger job than this skill does — say so and stop rather than attempting it.
- **Producing a large, multi-part planning document** (business objectives, stakeholder groups, a full risk register). This skill produces one **feature-level requirement**. If the sources clearly describe more scope than a single feature, say so and propose splitting into multiple requirements rather than force-fitting everything into one file.

## Inputs

- **input-sources** (required): one or more input sources, comma-separated. Each may be:
  - a local text/markdown file (`.txt`, `.md`)
  - a local PDF (`.pdf`)
  - a local image (`.png`, `.jpg`, `.jpeg` — a screenshot, whiteboard photo, mockup)
  - a URL (a live page, a shared doc link)
  - a path to a code repo or directory (read as supporting context — existing behavior, naming, current UI — not transcribed wholesale)
- **output-path** (optional): where to write the generated requirement. If omitted, derive one — see Step 4.

## Steps

### 1. Read every source, per its type

Read all sources in parallel where the tool allows it — they're independent of each other until Step 3.

| Source type | How to read it |
|---|---|
| `.txt` / `.md` | Read directly. |
| `.pdf` | Read directly (the Read tool extracts text/pages); for a large PDF, request specific page ranges rather than the whole thing blind. |
| Image (`.png`/`.jpg`/etc.) | Read directly — treat it as a screenshot or whiteboard photo; transcribe visible text, UI structure, and any handwritten annotations. |
| URL | Fetch it. |
| Code repo / directory | Do not transcribe the codebase. Skim for the specific thing the requirement is about: relevant component/route names, existing behavior worth preserving or replacing, naming conventions already in use. Note file paths for anything you cite — a requirement that says "as seen in `src/foo`" is checkable; one that doesn't isn't. |

For each source, keep a short scratch note of what it contributed. You need this to cite sources in Step 5's report — don't merge everything into one undifferentiated blob before you've tracked provenance.

### 2. Load the template

Read `requirement-template.md` in full before drafting anything, resolving its path relative to **this skill's own directory** (the folder this `SKILL.md` file is in) — never relative to the current working directory, the output path, or any of the input sources. That's what lets this skill's folder be copied or moved anywhere without breaking.

The template's own usage-notes block (delete it from the final document) spells out the rules that govern every section: extract only what sources explicitly state, cite the source for every requirement and business rule, and **never write a bracket placeholder or "[Not specified]" in the output — omit the section entirely instead** when the sources don't support it. Follow those rules exactly; they take precedence over filling every heading for the sake of completeness.

### 3. Synthesize — don't just concatenate, and don't invent

Cross-reference the sources against each other before writing:

- If two sources disagree, record it under **Gaps & Open Questions → Conflicts Between Sources** rather than silently picking one.
- If a source describes UI details a screenshot also shows, cite the richer one and note that the other confirms it.
- Group **Functional Requirements** under sub-headings by area/flow (e.g. "Filtering", "Export") when the sources describe more than one area, rather than as one flat list.
- **Never invent a specific number or name that isn't in a source** — response times, uptime targets, timeout values, capacity limits, browser/platform lists, technology choices, and similar specifics are the most common hallucinations. If a source doesn't state it explicitly, leave it out; don't estimate a "reasonable" value.
- Omit a whole section (Non-Functional Requirements, Data Requirements, Integration Requirements, etc.) when no source has content for it — don't keep the heading with a placeholder.
- Anything the sources leave unresolved — a missing detail, a conflict, an unanswered question — goes in **Gaps & Open Questions**, tagged `[NEEDS CLARIFICATION]`; an assumption made to fill a gap goes in **Assumptions**, tagged `[ASSUMPTION]`. Use these exact tags (not paraphrases) — other tools that consume this document key off them literally to find open items instead of re-reading the whole file.
- If the sources describe more than one distinct feature, stop and ask which one this pass is for (or whether to produce one file per feature), rather than merging unrelated features into a single requirement.

### 4. Determine the output path

- If **output-path** was given, use it.
- Otherwise, derive `requirement-<slug>.md` in the current directory, where `<slug>` is a short kebab-case name from the feature title.

Log the derived path before writing — cheap insurance against silently overwriting the wrong file.

### 5. Write and report

Write the file once, fully composed — no post-write edit passes to patch in sections.

Report:

- The output path.
- Which source contributed which parts (one line each), so the reader can trace a claim back to its origin.
- Everything logged under **Gaps & Open Questions** — don't make the reader hunt for it.
- Any section you omitted for lack of source coverage, if that's notable (e.g. "no Non-Functional Requirements — sources had none").
- Anything deliberately left out because it belonged to a different feature.

## Scope

This skill produces **one requirement document per run**. It does not reconcile it against other requirements, and it does not touch any file other than the one it writes and, on first use in a project with no template yet, `requirement-template.md` itself.
