# {{ Feature Name }} - Requirement

---
**TEMPLATE USAGE NOTES** (delete this whole block from the final document — it is authoring guidance, not content):

- This is a **feature-level** requirement — one feature, one document. It is not a project charter: sections like Stakeholders, Success Metrics/KPIs, and Time-Based Workflows only belong here if the sources genuinely tie them to this one feature.
- Only include sections where there is meaningful content. **Never write "[Not specified]" or leave a bracket placeholder in the final document — omit the section entirely instead.**
- Extract only what the sources say. Do not invent requirements, priorities, business value, or numbers.
- Cite the source for every requirement and every business rule (a file name, URL, page/section, or timestamp — whatever identifies where it came from).
- Focus on WHAT/WHY (requirements), not HOW (implementation). A requirement should be testable — a reader should be able to tell whether it was met.
- Route anything unresolved — a gap, a conflict between sources, a question nobody answered — to **Gaps & Open Questions**, tagged `[NEEDS CLARIFICATION]`. Tag anything assumed to fill a gap under **Assumptions** as `[ASSUMPTION]`. Use these exact tags, verbatim, rather than paraphrasing them — tools downstream of this document (e.g. anything that turns it into a prototype) key off the literal tag to find open items without re-reading the whole file.

**ANTI-HALLUCINATION RULES (critical):**
Never invent, even if plausible: response times, uptime/SLA targets, timeout values, concurrent-user or capacity numbers, browser/platform support lists, technology stack choices, UI positioning details, auto-dismiss timers, or any other numeric/specific value not explicitly stated in a source.
**When in doubt: if you cannot cite the specific source for a number or name, omit it.**
---

**Document Status:** [Draft | In Review | Approved]
**Last Updated:** [Date]
**Sources Analyzed:** [List of source materials — files, URLs, screenshots, repo paths]

---

## Overview

> Brief description of the feature: what it is, why it exists, and its boundaries. Omit any of the three fields below that the sources don't support.

**Purpose:** [The problem this feature solves or the outcome it enables]

**Scope:** [What is in scope, and what is explicitly out of scope]

**Background:** [Relevant history — a prior/legacy behavior, a past decision, a related feature this builds on]

---

## Source Analysis

> Include this section whenever more than one source was used, or a source needed interpretation.

**Sources Analyzed:**
- [Source name/path/URL] — [what was extracted from it]
- [Source name/path/URL] — [what was extracted from it]

**Source Quality Notes:**
- [Conflicts between sources, outdated information, or assumptions made while reconciling them]

---

## Functional Requirements

> What the feature must do. Number each requirement; give it a short name. Every field below except the requirement statement itself may be omitted if the sources don't cover it — but the source citation should almost always be present.

1. **[Requirement name]**: [Clear, testable statement of what the system must do]
   - **Business Justification:** [Why this is needed, if stated]
   - **User Impact:** [Who benefits and how, if stated]
   - **Acceptance Criteria:**
     - [Observable condition that confirms this requirement is met]
     - [Observable condition that confirms this requirement is met]
   - **Priority:** [P1/P2/P3 — only if the sources indicate relative priority]
   - **Source:** [Citation]

2. **[Requirement name]**: [...]

<!-- Group requirements under ### sub-headings by area/flow (e.g. "Filtering", "Export") when the sources describe more than one area. -->

---

## Business Rules

> Logic, validation, calculations, or workflow rules that govern this feature's behavior. Omit this section if the sources describe no such rules.

1. **[Rule name]**: [Statement of the rule]
   - **Rationale:** [Why this rule exists, if stated]
   - **Source:** [Citation]

---

## Non-Functional Requirements

> Only include a line here if a source states a **specific, explicit** value. Do not estimate or assume typical values (e.g. do not write "< 2s response time" or "99.9% uptime" unless a source says exactly that). Omit the whole section if nothing qualifies.

- **[Performance / Security / Reliability / Usability / Accessibility, etc.]:** [Explicit requirement, with source]

---

## UI Specifications

> What changes visually or structurally, drawn from screenshots, wireframes, or descriptions in the sources. Omit if no source touched the UI.

- [UI detail, with source]

---

## Data Requirements

> Entities, attributes, or data handling rules the feature introduces or depends on. Omit if not covered by the sources. Do not estimate volumes or retention periods that aren't explicitly stated.

- [Data requirement, with source]

---

## Integration Requirements

> External systems, APIs, or data exchange this feature depends on. Omit if not covered by the sources.

- [Integration requirement, with source]

---

## Dependencies

> Only the subsections that apply.

**Requirement Dependencies:**
- [Another requirement/feature this one depends on, and why]

**Technical Dependencies:**
- [A system, library, or capability that must already exist]

---

## Assumptions

> Assumptions made while extracting this requirement that may need validation. Omit if none were needed. Tag each one `[ASSUMPTION]`, verbatim — it's the marker other tools look for.

1. **[ASSUMPTION]** [Assumption]: [What is being assumed, and why]
   - **Impact if invalid:** [What breaks if this assumption is wrong]

---

## Constraints

> Limitations affecting this feature's scope or approach, if the sources state any. Omit otherwise.

- [Constraint, with source]

---

## Negative Scope

> What this feature explicitly does not change or add. This is what keeps the requirement's boundary legible — include it even when short.

- [Explicitly out-of-scope item]

---

## Gaps & Open Questions

> Everything unresolved goes here — missing information, conflicts between sources, and questions nobody has answered yet. Omit this section only if there is genuinely nothing to flag. Tag each item `[NEEDS CLARIFICATION]`, verbatim — it's the marker other tools look for.

**Requirement Gaps:**
- **[NEEDS CLARIFICATION]** [What's missing]: [Why it matters, and who could resolve it, if known]

**Conflicts Between Sources:**
- **[NEEDS CLARIFICATION]** [Conflict]: [Source A says X; Source B says Y — which is correct, or is a new decision needed]

**Clarifications Needed:**
- **[NEEDS CLARIFICATION]** [Question]: [Why it needs an answer before this requirement is actionable]
