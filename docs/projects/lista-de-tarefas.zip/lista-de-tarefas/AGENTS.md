Lista de Tarefas

## Descrição
App para o usuário anotar tarefas que precisa realizar, organizá-las (por data, prioridade ou categoria) e marcá-las como concluídas conforme vai executando. O objetivo é ajudar a pessoa a não esquecer compromissos e ter uma visão clara do que falta fazer no dia, na semana etc.

## Objetivo do produto
Ser uma ferramenta simples e rápida de usar, acessível pelo navegador, sem necessidade de instalação, para gestão pessoal de tarefas do dia a dia.

## Público-alvo
Usuários individuais que querem organizar tarefas pessoais ou profissionais de forma leve, sem a complexidade de ferramentas corporativas de gestão de projetos.

## Requisitos funcionais
- Criar tarefa com: título (obrigatório), descrição (opcional), data/hora (obrigatórios), prioridade (alta/média/baixa) e categoria (lista predefinida e estática: Pessoal, Trabalho, Outras)
- Editar e excluir tarefas
- Marcar tarefa como concluída ou reabrir uma tarefa concluída
- Filtrar e ordenar tarefas por data, prioridade ou categoria (ordem padrão por prioridade com desempate por data/hora mais recente no topo)
- Categorias predefinidas e estáticas: Pessoal, Trabalho, Outras (sem criação, edição ou exclusão de categorias)
- Buscar tarefas por palavra-chave
- Visualizar tarefas pendentes por dia, semana ou "todas"
- Indicar visualmente tarefas atrasadas

## Requisitos não funcionais
- Rodar direto no navegador, sem instalação
- Layout responsivo (funcionar bem em desktop com tamanhos diversos de monitor)
- Interface simples e intuitiva, sem curva de aprendizado
- Tempo de resposta rápido nas ações (adicionar, concluir, filtrar)

## Desafio de design
- Priorização, categorização e hierarquia de tarefas

## Fora de escopo
- Colaboração entre múltiplos usuários
- Notificações push/e-mail
- Integração com calendários externos
- Persistência dos dados
- Criação, edição ou exclusão de categorias personalizadas (a lista de categorias é predefinida e estática)