Meditação e Foco

## Descrição
App que ajuda o usuário a manter concentração ou relaxar através de temporizadores (como ciclos de foco e descanso no método Pomodoro) ou sessões guiadas de meditação/respiração. Geralmente tem sons ambientes, lembretes de pausa e acompanhamento de quanto tempo a pessoa dedicou ao foco/relaxamento.

## Objetivo do produto
Ajudar o usuário a melhorar sua concentração e bem-estar através de sessões estruturadas de foco ou relaxamento, com o mínimo de fricção possível para começar a usar.

## Público-alvo
Pessoas que buscam melhorar produtividade (técnica Pomodoro) ou reduzir estresse/ansiedade através de pausas guiadas de respiração/meditação.

## Requisitos funcionais
- Iniciar sessão de foco com temporizador configurável (ex: ciclos de 25min foco / 5min pausa)
- Iniciar sessão de meditação/respiração guiada com duração pré-definida
- Reproduzir sons ambientes durante a sessão (ex: chuva, natureza, ruído branco)
- Notificar o usuário ao final de cada ciclo (foco, pausa, sessão)
- Pausar, retomar ou encerrar uma sessão em andamento
- Visualizar histórico de tempo dedicado a foco/relaxamento (ex: por dia/semana)
- Escolher entre diferentes tipos de sessão (foco, respiração, meditação livre)

## Requisitos não funcionais
- Rodar direto no navegador, sem instalação
- Layout responsivo (funcionar bem em desktop e mobile)
- Onboarding rápido, permitindo iniciar a primeira sessão em poucos cliques
- Interface minimalista, sem elementos visuais que distraiam durante a sessão
- Estados de espera (contagem de tempo, transições entre ciclos) com feedback visual calmo e claro

## Direção de design
Onboarding simples, estados de espera, minimalismo

## Fora de escopo (v1)
- Biblioteca extensa de meditações guiadas com narração humana
- Integração com calendário para agendar sessões
- Estatísticas avançadas (ex: comparação com outros usuários)
- Persistência dos dados