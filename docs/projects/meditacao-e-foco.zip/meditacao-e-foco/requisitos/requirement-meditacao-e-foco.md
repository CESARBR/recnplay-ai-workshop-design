# My Moment (Meditação e Foco) - Requirement

**Document Status:** Draft  
**Last Updated:** 2026-09-28  
**Sources Analyzed:**  
- `AGENTS.md` (Product specification for Meditação e Foco)  
- `DESIGN.md` (Design system and UI specifications for My Moment)  

---

## Overview

**Purpose:** Ajudar o usuário a melhorar sua concentração e bem-estar através de sessões estruturadas de foco ou relaxamento, com o mínimo de fricção possível para começar a usar.

**Scope:** Sessões de foco com temporizador configurável (ciclos de foco e pausa no método Pomodoro), sessões de meditação/respiração guiada com duração pré-definida, meditação livre, reprodução de sons ambientes durante as sessões, controle completo de execução (iniciar, pausar, retomar, encerrar), notificações ao final de cada ciclo e acompanhamento de histórico de tempo dedicado ao foco/relaxamento.

**Background:** Aplicativo voltado a produtividade e redução de estresse ("My Moment"), atendendo usuários da técnica Pomodoro e praticantes de pausas guiadas de respiração e meditação, rodando diretamente no navegador com interface minimalista e calma.

---

## Source Analysis

**Sources Analyzed:**
- `AGENTS.md` — Descrição do produto, objetivo, público-alvo, requisitos funcionais, requisitos não funcionais, direção de design e escopo negativo da v1.
- `DESIGN.md` — Nome do produto ("My Moment"), tokens semânticos de cor, tipografia, espaçamento, raios de borda, elevação/profundidade, especificações de componentes base e diretrizes visuais (Do's and Don'ts).

**Source Quality Notes:**
- As fontes `AGENTS.md` e `DESIGN.md` são consistentes e complementares. O `AGENTS.md` estabelece a funcionalidade, público e limites de escopo, enquanto o `DESIGN.md` fornece os tokens semânticos e regras visuais.
- `AGENTS.md` define que persistência de dados está fora de escopo na v1, enquanto requer histórico de tempo dedicado (ex.: por dia/semana). Dessa forma, assume-se gerenciamento de histórico no ciclo de vida da sessão/memória local sem persistência remota/banco de dados na v1.
- Sons ambientes (chuva, natureza, ruído branco) e ciclos de foco (25 min foco / 5 min pausa) são citados como exemplos (`ex:`) em `AGENTS.md`; parâmetros exatos de catálogo e durações foram registrados em Gaps & Open Questions.

---

## Functional Requirements

### Tipos e Configuração de Sessão

1. **Escolha de Tipo de Sessão**: O sistema deve permitir ao usuário escolher entre três tipos de sessão: sessão de foco, sessão de respiração guiada e meditação livre.
   - **Business Justification:** Atender a diferentes intenções de uso (aumento de produtividade ou relaxamento/descompressão).
   - **User Impact:** Permite ao usuário selecionar rapidamente a modalidade desejada com mínima fricção.
   - **Acceptance Criteria:**
     - O usuário visualiza as opções de foco, respiração e meditação livre.
     - A seleção altera o modo e prepara a interface para o tipo de sessão correspondente.
   - **Source:** `AGENTS.md` (Requisitos funcionais, "Escolher entre diferentes tipos de sessão (foco, respiração, meditação livre)")

2. **Temporizador de Foco Configurável**: O sistema deve permitir iniciar uma sessão de foco com temporizador configurável de ciclos de foco e pausa (ex.: ciclos de 25 minutos de foco e 5 minutos de pausa).
   - **Business Justification:** Suportar a técnica Pomodoro e adaptações a rotinas de trabalho individuais.
   - **User Impact:** O usuário tem flexibilidade para ajustar as durações conforme sua capacidade de concentração e tarefas.
   - **Acceptance Criteria:**
     - O usuário pode configurar ou ajustar o tempo do ciclo de foco.
     - O usuário pode configurar ou ajustar o tempo do ciclo de pausa.
     - O temporizador inicia a contagem com os valores configurados.
   - **Source:** `AGENTS.md` (Requisitos funcionais, "Iniciar sessão de foco com temporizador configurável (ex: ciclos de 25min foco / 5min pausa)")

3. **Sessão Guiada de Meditação e Respiração**: O sistema deve permitir iniciar sessão guiada de meditação/respiração com duração pré-definida.
   - **Business Justification:** Fornecer alívio rápido de estresse e ansiedade com mínimo esforço de configuração.
   - **User Impact:** O usuário inicia práticas de respiração/meditação guiada em poucos cliques.
   - **Acceptance Criteria:**
     - O usuário pode selecionar entre opções de duração pré-definida para a sessão.
     - O sistema inicia a sessão guiada aplicando a duração escolhida.
   - **Source:** `AGENTS.md` (Requisitos funcionais, "Iniciar sessão de meditação/respiração guiada com duração pré-definida")

### Execução e Controle de Sessão

4. **Controle de Execução da Sessão**: O sistema deve permitir pausar, retomar ou encerrar uma sessão em andamento a qualquer momento.
   - **Business Justification:** Oferecer flexibilidade para lidar com interrupções sem comprometer o fluxo de uso.
   - **User Impact:** O usuário mantém o controle sobre seu tempo e pode interromper ou encerrar a sessão quando necessário.
   - **Acceptance Criteria:**
     - Durante a contagem, uma ação de pausar interrompe o relógio mantendo o tempo restante congelado.
     - Em estado pausado, uma ação de retomar prossegue a contagem a partir do ponto onde parou.
     - Uma ação de encerrar finaliza a sessão corrente e retorna ao estado inicial ou tela de resumo.
   - **Source:** `AGENTS.md` (Requisitos funcionais, "Pausar, retomar ou encerrar uma sessão em andamento")

5. **Notificação de Término de Ciclo**: O sistema deve notificar o usuário ao final de cada ciclo (ciclo de foco, ciclo de pausa ou término da sessão).
   - **Business Justification:** Avisar a transição de momento sem exigir que o usuário olhe para a tela constantemente.
   - **User Impact:** Permite focar ou relaxar com os olhos fechados sabendo que será avisado na hora certa.
   - **Acceptance Criteria:**
     - Ao zerar o tempo de foco, uma notificação indica o encerramento do foco e o início da pausa.
     - Ao zerar o tempo de pausa, uma notificação indica o encerramento da pausa.
     - Ao zerar uma sessão guiada ou meditação com tempo estipulado, uma notificação sinaliza a conclusão.
   - **Source:** `AGENTS.md` (Requisitos funcionais, "Notificar o usuário ao final de cada ciclo (foco, pausa, sessão)")

6. **Feedback Visual de Estados de Espera e Transição**: O sistema deve apresentar feedback visual calmo e claro durante os estados de espera (contagem de tempo) e nas transições entre ciclos.
   - **Business Justification:** Reforçar a sensação de serenidade e clareza, evitando qualquer sobressalto ou ansiedade visual.
   - **User Impact:** O usuário acompanha visualmente o progresso do tempo com conforto estético.
   - **Acceptance Criteria:**
     - A interface exibe a contagem de tempo de forma limpa, sem animações agressivas ou ruído visual.
     - A transição entre os estados de foco e pausa é visualmente evidente e suave.
   - **Source:** `AGENTS.md` (Requisitos não funcionais, "Estados de espera (contagem de tempo, transições entre ciclos) com feedback visual calmo e claro")

### Sons Ambientes

7. **Reprodução de Sons Ambientes**: O sistema deve reproduzir sons ambientes durante a sessão (ex.: chuva, natureza, ruído branco).
   - **Business Justification:** Auxiliar no isolamento de ruídos externos e induzir relaxamento ou imersão no foco.
   - **User Impact:** Usuário pode personalizar a ambientação acústica da sua prática.
   - **Acceptance Criteria:**
     - O usuário pode escolher entre sons ambientes disponíveis (ex.: chuva, natureza, ruído branco) ou optar por silêncio.
     - O áudio toca sincronizado à sessão ativa e é pausado/interrompido junto com o temporizador.
   - **Source:** `AGENTS.md` (Requisitos funcionais, "Reproduzir sons ambientes durante a sessão (ex: chuva, natureza, ruído branco)")

### Histórico e Acompanhamento

8. **Visualização de Histórico de Tempo Dedicado**: O sistema deve permitir ao usuário visualizar o histórico de tempo dedicado a foco e relaxamento (ex.: por dia/semana).
   - **Business Justification:** Estimular a consistência e fornecer senso de realização sobre o tempo investido.
   - **User Impact:** O usuário tem visibilidade de sua dedicação acumulada.
   - **Acceptance Criteria:**
     - A interface exibe o total de tempo acumulado dedicado a sessões de foco e de relaxamento.
     - O usuário pode alternar a visualização por períodos (ex.: dia ou semana).
   - **Source:** `AGENTS.md` (Requisitos funcionais, "Visualizar histórico de tempo dedicado a foco/relaxamento (ex: por dia/semana)")

---

## Business Rules

1. **Sequência do Ciclo Pomodoro**: Ao término de um ciclo de foco, o fluxo subsequente deve apontar para o ciclo de pausa configurado antes de iniciar um novo ciclo de foco.
   - **Rationale:** Estrutura fundamental do método Pomodoro para garantir descanso regenerativo entre blocos de concentração.
   - **Source:** `AGENTS.md` (Requisitos funcionais: "ciclos de 25min foco / 5min pausa", "Notificar o usuário ao final de cada ciclo (foco, pausa, sessão)")

2. **Uso Moderado da Cor Terciária**: A cor terciária (`#1CD9AA`) deve ser utilizada com moderação, reservada estritamente para a ação de maior ênfase visual na tela (ex.: ação primária de iniciar/retomar a sessão).
   - **Rationale:** Preservar a tranquilidade da interface e orientar o foco cognitivo sem poluição visual.
   - **Source:** `DESIGN.md` (Do's and Don'ts: "Do use the tertiary color sparingly — only for the highest-emphasis action")

3. **Restrição Tipográfica**: A aplicação deve utilizar no máximo duas famílias tipográficas na interface (`Public Sans` e `Space Grotesk`).
   - **Rationale:** Manter consistência estética, elegância editorial e legibilidade minimalista.
   - **Source:** `DESIGN.md` (Do's and Don'ts: "Don't combine more than two type families on a single screen")

4. **Aplicação do Fundo Neutro e Superfícies**: O fundo padrão da aplicação deve adotar a cor neutra quente (`#F7F8F8`), reservando o branco puro (`#FFFFFF`) para superfícies de cards e elementos de entrada.
   - **Rationale:** Garantir contraste suave e acabamento matte sem ofuscamento visual.
   - **Source:** `DESIGN.md` (Do's and Don'ts: "Do default to the warm neutral background; reserve pure white for cards")

---

## Non-Functional Requirements

- **Portabilidade e Execução:** O aplicativo deve rodar diretamente no navegador web, sem necessidade de instalação (`AGENTS.md`).
- **Responsividade:** O layout deve ser responsivo, funcionando adequadamente em dispositivos desktop e mobile (`AGENTS.md`).
- **Usabilidade / Onboarding:** O onboarding deve ser rápido, permitindo ao usuário iniciar a primeira sessão em poucos cliques (`AGENTS.md`).
- **Ergonomia Visual:** A interface deve ser minimalista, sem elementos visuais que distraiam o usuário durante a realização da sessão (`AGENTS.md`).
- **Feedback e Espera:** Os estados de espera (contagem de tempo, transições entre ciclos) devem fornecer feedback visual calmo e claro (`AGENTS.md`).

---

## UI Specifications

- **Identidade e Estilo:** Minimalismo arquitetônico com acabamento fosco premium ("matte finish"), remetendo a periódicos de alta qualidade ou galerias contemporâneas (`DESIGN.md`).
- **Paleta de Cores Semântica:**
  - `primary`: `#141F1C` (texto principal e elementos estruturais escuros)
  - `secondary`: `#5B7B73` (textos de apoio, subtítulos e elementos secundários)
  - `tertiary`: `#1CD9AA` (ação de máxima ênfase / destaque primário)
  - `neutral`: `#F7F8F8` (fundo principal da página)
  - `surface`: `#FFFFFF` (superfície de cards e inputs)
  - `on-tertiary`: `#0A0A0A` (texto sobre botões e elementos terciários)
  - `border`: `#E3E8E7` (bordas sutis tipo hairline)
  - *(Fonte: `DESIGN.md`)*
- **Tipografia:**
  - `h1`: Public Sans, tamanho `3rem` (48px), peso `700` (`DESIGN.md`)
  - `body-md`: Public Sans, tamanho `1rem` (16px), peso `400` (`DESIGN.md`)
  - `label-caps`: Space Grotesk, tamanho `0.75rem` (12px), peso `600` (`DESIGN.md`)
- **Espaçamento:**
  - `spacing.sm`: `8px` (`DESIGN.md`)
  - `spacing.md`: `16px` (`DESIGN.md`)
  - `spacing.lg`: `24px` (`DESIGN.md`)
- **Elevação e Profundidade:**
  - Profundidade criada por camadas tonais e bordas sutis tipo hairline, em vez de sombras pronunciadas (drop shadows) (`DESIGN.md`).
  - Cards elevam-se do fundo neutro através da superfície branca e borda simples (`DESIGN.md`).
- **Cantos Arredondados:**
  - `rounded.sm`: `4px` (`DESIGN.md`)
  - `rounded.md`: `8px` (`DESIGN.md`)
- **Componentes Base:**
  - `button-primary`: Fundo `{colors.tertiary}`, cor de texto `{colors.on-tertiary}`, raio `4px` (`rounded.sm`), padding `12px 20px` (`DESIGN.md`).
  - `button-secondary`: Fundo transparente, cor de texto `{colors.tertiary}`, raio `4px` (`rounded.sm`), padding `12px 20px` (`DESIGN.md`).
  - `card`: Fundo `{colors.surface}`, cor de texto `{colors.primary}`, raio `8px` (`rounded.md`), padding `20px` (`DESIGN.md`).
  - `input`: Fundo `{colors.surface}`, cor de texto `{colors.primary}`, raio `4px` (`rounded.sm`), padding `10px 14px` (`DESIGN.md`).

---

## Data Requirements

- **Modelo de Sessão:** Estrutura que armazena tipo de sessão (foco, respiração, meditação livre), tempo configurado/total, tempo decorrido, estado (não iniciada, ativa, pausada, finalizada) e ciclo atual (foco vs. pausa) (`AGENTS.md`).
- **Modelo de Histórico:** Registros contendo data/hora, tipo de sessão e duração concluída em minutos/segundos para consolidação de tempo dedicado por período (dia/semana) (`AGENTS.md`).
- **Catálogo de Sons:** Lista de opções de áudio ambiente (chuva, natureza, ruído branco) e controle de estado ativo/inativo (`AGENTS.md`).
- **Regra de Armazenamento:** Os dados operam em memória local de execução durante a navegação, sem dependência de persistência permanente ou banco de dados externo (`AGENTS.md`).

---

## Dependencies

**Requirement Dependencies:**
- Não há requisitos anteriores registrados como pré-requisitos (`AGENTS.md`).

**Technical Dependencies:**
- Navegador web moderno com suporte a HTML5 Web Audio API (para reprodução de sons ambientes e avisos sonoros) e temporizadores JavaScript (`AGENTS.md`).

---

## Assumptions

1. **[ASSUMPTION]** Gestão de Histórico em Memória ou Estado Local da Aba: Dado que a persistência permanente de dados está explicitamente fora de escopo para a v1 (`AGENTS.md`), assume-se que o histórico de tempo dedicado seja gerenciado no estado em memória da aplicação durante a sessão do usuário (ou armazenamento temporário local do navegador), sendo reiniciado ou demonstrativo caso a página seja recarregada.
   - **Impact if invalid:** Se for exigida retenção de dados entre visitas e dispositivos, será necessário desenhar esquema de persistência e autenticação de contas de usuário.

2. **[ASSUMPTION]** Áudio Sintetizado ou Mockado em Web Audio: Assume-se que os sons ambientes (chuva, ruído branco, sons da natureza) e os avisos de final de ciclo sejam viabilizados através de áudio HTML5 / Web Audio API ou mock sonoro embutido, sem dependência de serviços externos de streaming sob assinatura.
   - **Impact if invalid:** A ausência de arquivos de áudio locais ou de suporte a Web Audio no navegador impedirá a funcionalidade sonora.

3. **[ASSUMPTION]** Notificações In-App e Alertas Sonoros: Assume-se que as notificações ao final de cada ciclo sejam primariamente avisos sonoros calmos combinados com atualizações visuais na tela (in-app), complementadas opcionalmente pela Web Notifications API do navegador mediante consentimento do usuário.
   - **Impact if invalid:** Se for mandatório enviar notificações de sistema com a aba em segundo plano ou fechada sem interação prévia, dependerá de service workers e permissões explícitas do navegador.

---

## Constraints

- Não requer instalação; operação 100% contida no navegador (`AGENTS.md`).
- Foco em interface despojada de distrações e com mínima fricção para início imediato (`AGENTS.md`).
- Respeito rigoroso aos tokens e regras do sistema de design ("My Moment") (`DESIGN.md`).

---

## Negative Scope

- Biblioteca extensa de meditações guiadas com narração humana (`AGENTS.md`).
- Integração com calendário para agendamento de sessões (`AGENTS.md`).
- Estatísticas avançadas (ex.: comparação com outros usuários ou rankings) (`AGENTS.md`).
- Persistência dos dados em banco de dados ou backend com autenticação (`AGENTS.md`).

---

## Gaps & Open Questions

**Requirement Gaps:**
- **[NEEDS CLARIFICATION]** Padrões e Técnicas da Sessão de Respiração Guiada: Quais são as durações fixas pré-definidas e os padrões de ritmo respiratório para a respiração guiada (ex.: técnica 4-7-8, respiração em quatro tempos/box breathing, ou durações simples de 3, 5 ou 10 minutos)?
- **[NEEDS CLARIFICATION]** Funcionamento e Contagem da Meditação Livre: Na opção de "meditação livre", o temporizador deve funcionar como cronômetro progressivo aberto (sem tempo limite prévio) ou como temporizador regressivo configurável pelo usuário?
- **[NEEDS CLARIFICATION]** Estrutura e Métricas do Histórico: Quais indicadores exatos devem ser exibidos na visualização por dia/semana (ex.: minutos totais acumulados, quantidade de ciclos concluídos, gráfico de barras comparativo por dia da semana)?

**Clarifications Needed:**
- **[NEEDS CLARIFICATION]** Tipo e Som da Notificação de Ciclo: Qual tipo de sinal sonoro deve ser reproduzido nas transições (ex.: sino tibetano, carrilhão suave, gongo) e deve haver opção de mutar a notificação sonora mantendo apenas a visual?
- **[NEEDS CLARIFICATION]** Comportamento em Segundo Plano: O temporizador deve tentar emitir Web Notifications nativas do sistema operacional se a aba do navegador não estiver em foco durante o término do ciclo?
