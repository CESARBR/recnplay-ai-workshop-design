Organizador de Receitas

## Descrição
App para salvar, buscar e organizar receitas culinárias favoritas. Costuma incluir lista de ingredientes, modo de preparo passo a passo, fotos do prato, tempo de preparo e opções de filtro (por tipo de refeição, restrição alimentar, tempo disponível etc.).

## Objetivo do produto
Facilitar a organização e o acesso a receitas favoritas, tornando simples encontrar a receita certa de acordo com contexto, tempo disponível e preferências alimentares.

## Público-alvo
Pessoas que cozinham com frequência e querem centralizar suas receitas favoritas em um só lugar, com facilidade para buscar e filtrar por diferentes critérios.

## Requisitos funcionais
- Criar receita com: título, foto, lista de ingredientes, modo de preparo (passo a passo), tempo de preparo e categoria/tipo de refeição
- Editar e excluir receitas
- Marcar receita como favorita
- Buscar receitas por nome, ingrediente ou categoria
- Filtrar receitas por tipo de refeição, restrição alimentar (ex: vegetariano, sem lactose) e tempo de preparo
- Visualizar receita em modo "passo a passo" durante o preparo
- Ajustar quantidade de ingredientes por número de porções (opcional)
- Organizar receitas em coleções personalizadas (ex: "Jantares rápidos", "Sobremesas")

## Requisitos não funcionais
- Rodar direto no navegador, sem instalação
- Layout responsivo (funcionar bem em desktop e mobile)
- Interface visualmente atrativa, com destaque para fotos e apresentação do conteúdo
- Busca e filtros rápidos e intuitivos, mesmo com muitas receitas cadastradas

## Direção de design
Busca, filtros e apresentação visual de conteúdo (fotos, passos)

## Fora de escopo (v1)
- Compartilhamento de receitas entre usuários
- Importação automática de receitas de sites externos
- Lista de compras integrada
- Persistência dos dados