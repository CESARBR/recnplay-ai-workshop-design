Controle de Gastos Pessoais

## Descrição
App para registrar despesas (e às vezes receitas) do dia a dia, organizá-las por categoria (alimentação, transporte, lazer, outras.) e visualizar para onde o dinheiro está indo através de gráficos e resumos. Ajuda o usuário a entender e controlar seu orçamento mensal.

## Objetivo do produto
Dar ao usuário clareza sobre seus hábitos financeiros, facilitando o controle do orçamento mensal através de registro simples e visualização de dados acessível.

## Público-alvo
Pessoas que querem entender e controlar melhor seus gastos pessoais, sem precisar de ferramentas complexas de gestão financeira.

## Requisitos funcionais
- Registrar despesa com: valor, categoria, data e descrição (opcional)
- Registrar receita com: valor, origem, data e descrição (opcional)
- Categorias predefinidas
- Editar e excluir lançamentos
- Visualizar resumo do mês (total de gastos, total de receitas, saldo)
- Visualizar gráfico de gastos por categoria (ex: pizza ou barras)
- Visualizar evolução de gastos ao longo do tempo (ex: por semana/mês)
- Filtrar lançamentos por categoria, data ou tipo (despesa/receita)
- Definir um orçamento mensal (opcional) e comparar com o gasto real

## Requisitos não funcionais
- Rodar direto no navegador, sem instalação
- Layout responsivo (funcionar bem em desktop e mobile)
- Interface simples, com linguagem e visuais que não intimidem o usuário
- Gráficos claros e fáceis de interpretar, mesmo para quem não tem afinidade com números

## Direção de design
Visualização de dados (gráficos, categorias) de forma simples e não intimidadora

## Fora de escopo (v1)
- Integração bancária automática (importação de extratos)
- Múltiplas contas/carteiras
- Conversão de moedas
- Persistência dos dados
- Criação, edição ou exclusão de categorias personalizadas (a lista de categorias é predefinida e estática)