Rastreador de Hábitos (Habit Tracker)

## Descrição
App onde o usuário cadastra hábitos que quer manter ou construir (ex: beber água, ler, exercitar-se) e marca diariamente se cumpriu ou não. Geralmente mostra sequências (streaks), calendários visuais e estatísticas de consistência ao longo do tempo, funcionando como reforço motivacional.

## Objetivo do produto
Ajudar o usuário a criar e manter hábitos positivos através de acompanhamento simples e feedback visual que reforce o progresso e a consistência.

## Público-alvo
Pessoas que querem desenvolver ou manter rotinas (saúde, produtividade, bem-estar) e se beneficiam de acompanhamento visual e reforço motivacional para não desistir.

## Requisitos funcionais
- Criar hábito com: nome, frequência desejada (diário, dias específicos da semana, X vezes por semana) e ícone/cor
- Marcar hábito como cumprido ou não cumprido no dia
- Editar e excluir hábitos
- Visualizar sequência atual (streak) e melhor sequência (recorde)
- Visualizar calendário mensal com histórico de cumprimento de cada hábito
- Visualizar estatísticas de consistência (ex: % de dias cumpridos no mês)
- Listar todos os hábitos do dia em uma tela única
- Arquivar/pausar hábitos sem perder o histórico

## Requisitos não funcionais
- Rodar direto no navegador, sem instalação
- Layout responsivo (funcionar bem em desktop e mobile)
- Interface visualmente agradável e motivadora (cores, ícones, feedback de progresso)
- Ações rápidas para marcar hábitos (idealmente 1 clique/toque)

## Direção de design
- Forte apelo visual e feedback de progresso com animações

## Fora de escopo (v1)
- Lembretes/notificações programadas
- Compartilhamento social de progresso
- Integração com wearables ou apps de saúde
- Persistência dos dados